/**
 * Created by Hilk on 17.02.2017.
 */
alert("Run!");
var tablePower = document.getElementById('TablePower');
var count = 0;
var date = new Date();
var sec = 0;
alert(sec);
while(true) {
    sec = date.getSeconds();
    if (+min == 10) {
    alert(tablePower);
    for (var i = 1; i <= tablePower.rows.length; i++ ){
        for (var j = 2; j <=tablePower.rows.length; j++){
            tablePower.rows[i].cells[j].innerHTML = count;
            count ++;
        }
    }
    break;
    }
}